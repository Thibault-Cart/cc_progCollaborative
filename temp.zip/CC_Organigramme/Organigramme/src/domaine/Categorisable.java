package domaine;

public interface Categorisable {
    public String getCategorie();

    public int getNo();
}
